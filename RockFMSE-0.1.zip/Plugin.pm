package Plugins::RockFMSE::Plugin;

# Visar artist, titel och omslag för Rock FM Sverige i Lyrion.
# Hämtar "Spelas nu" från rockfm.se/playlist högst var 30:e sekund.

use strict;
use base qw(Slim::Plugin::Base);

use HTML::Entities;
use Time::HiRes;

use Slim::Formats::RemoteMetadata;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Slim::Utils::Unicode;

my $log = Slim::Utils::Log->addLogCategory({
	category     => 'plugin.rockfmse',
	defaultLevel => 'WARN',
	description  => 'PLUGIN_ROCKFMSE',
});

my $BASE     = 'https://www.rockfm.se';
my $PAGE     = $BASE . '/playlist';
my $LOGO     = $BASE . '/uploads/stations/6582c2c4-cff9-4cbd-91c0-1e100737a39a-w150.png';
my $INTERVAL = 30;

my $meta      = {};
my $lastFetch = 0;
my $fetching  = 0;

sub initPlugin {
	my $class = shift;
	$class->SUPER::initPlugin(@_);

	Slim::Formats::RemoteMetadata->registerProvider(
		match => qr/revma\.com\/bu3gs96x4gpwv/,
		func  => \&provider,
	);
}

sub provider {
	my ($client, $url) = @_;

	if (!$fetching && Time::HiRes::time() - $lastFetch > $INTERVAL) {
		_fetch($client);
	}

	return { %$meta } if $meta->{title};

	return {
		title => 'Rock FM Sverige',
		icon  => $LOGO,
		cover => $LOGO,
	};
}

sub _fetch {
	my $client = shift;
	$fetching = 1;

	Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $http = shift;
			$fetching  = 0;
			$lastFetch = Time::HiRes::time();
			_parse($client, $http->content);
		},
		sub {
			my ($http, $error) = @_;
			$fetching  = 0;
			$lastFetch = Time::HiRes::time();
			$log->warn("Kunde inte hämta $PAGE: $error");
		},
		{ timeout => 15 },
	)->get($PAGE, 'User-Agent' => 'Mozilla/5.0');
}

sub _parse {
	my ($client, $html) = @_;
	return unless $html;

	$html = Slim::Utils::Unicode::utf8decode($html);

	my ($tag)    = $html =~ m{(<img[^>]*cp-player-album-art[^>]*>)}s;
	my ($src)    = $tag ? $tag =~ m{src="([^"]+)"} : ();
	my ($title)  = $html =~ m{class="cp-player-track-title">\s*([^<]*?)\s*<}s;
	my ($artist) = $html =~ m{class="cp-player-artist-name">\s*([^<]*?)\s*<}s;

	unless ($title) {
		$log->info('Hittade ingen låttitel på sidan');
		return;
	}

	$title  = decode_entities($title);
	$artist = decode_entities($artist || '');

	my $cover = $LOGO;
	if ($src && $src !~ /missingCover/) {
		$src =~ s/-(th|sm|md)\.jpg/-lg.jpg/;
		$cover = $src =~ m{^https?://} ? $src : $BASE . $src;
	}

	return if ($meta->{title} // '') eq $title && ($meta->{artist} // '') eq $artist;

	$meta = {
		title  => $title,
		artist => $artist,
		cover  => $cover,
		icon   => $cover,
	};

	$log->info("Spelas nu: $artist - $title");

	if ($client) {
		$client->currentPlaylistUpdateTime(Time::HiRes::time());
		Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
	}
}

1;
